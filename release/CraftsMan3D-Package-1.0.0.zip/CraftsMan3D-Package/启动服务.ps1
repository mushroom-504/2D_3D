$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "没有找到 Docker。请先安装 Docker Desktop，并启用 NVIDIA GPU 支持。"
}

if (-not (Test-Path -LiteralPath ".env")) {
    Copy-Item -LiteralPath ".env.example" -Destination ".env"
    Write-Host "已创建 .env。需要账号或 Hugging Face 令牌时，请先编辑该文件。"
}

Write-Host "正在构建并启动 CraftsMan3D。首次运行会下载数 GB 模型，请保持网络连接。"
docker compose up --build -d
if ($LASTEXITCODE -ne 0) {
    throw "Docker 启动失败，请运行“查看日志.ps1”查看原因。"
}

Write-Host "服务已提交启动。模型下载和加载需要一些时间。"
Write-Host "查看日志：右键“查看日志.ps1”，选择使用 PowerShell 运行。"
Write-Host "网页地址：http://localhost:7860"
Start-Process "http://localhost:7860"
