# CraftsMan3D 图片转 3D 发布包

## 这个包里有什么

- CraftsMan3D 推理源码和网页界面；
- Docker 固定运行环境；
- NVIDIA GPU 环境检查；
- 首次启动自动下载模型；
- Windows 一键启动、停止和查看日志；
- 模型与输出的持久化目录。

模型权重没有放进 ZIP。首次启动会下载 `config.yaml` 和 `model.ckpt`。

## 使用要求

接收者电脑必须具备：

1. 64 位 Windows 10/11 或支持 Docker 的 Linux；
2. NVIDIA 显卡及可用驱动；
3. Docker Desktop；
4. Docker 的 NVIDIA GPU 支持；
5. 足够的显存、磁盘空间和可访问 Hugging Face 的网络。

本包不把 CPU 模式作为正式运行方式。Intel、AMD 显卡也不能直接使用
当前 CUDA 镜像。

## Windows 一键启动

1. 解压整个 ZIP，路径尽量不要包含特殊符号；
2. 启动 Docker Desktop，确认 Docker 已正常运行；
3. 双击 `启动服务.bat`；
4. 首次运行会构建镜像并下载数 GB 模型；
5. 打开 `http://localhost:7860`；
6. 上传一张主体清楚、背景干净的图片；
7. 点击 Generate，完成后下载 OBJ。

如果网页暂时打不开，双击 `查看日志.bat`。首次下载和加载模型可能需要
较长时间。

## 停止

双击 `停止服务.bat`。模型和生成结果不会被删除：

- 模型保存在 `models`；
- 输出保存在 `outputs`。

## 配置

首次启动会把 `.env.example` 复制为 `.env`。可编辑：

- `CRAFTSMAN_PORT`：网页端口；
- `CRAFTSMAN_MODEL_REPO`：Hugging Face 模型仓库；
- `CRAFTSMAN_MODEL_NAME`：本地模型目录名；
- `HF_TOKEN`：私有模型令牌；
- `CRAFTSMAN_USERNAME` 和 `CRAFTSMAN_PASSWORD`：网页账号密码。

不要把填写了真实令牌或密码的 `.env` 发给别人。

## API

Gradio 暴露名为 `generate_img2obj` 的接口。服务启动后可以在网页底部
查看 “Use via API” 获得当前 Gradio 版本对应的调用示例。

## 已知限制

- 只生成无纹理或基础材质网格，实际效果取决于输入图片和模型；
- 当前发布包没有捆绑 Instant Meshes，因此不要启用 Remesh；
- 同一张图可以尝试不同 seed、采样步数和 octree depth；
- 不要直接暴露到公网；如需公网服务，应增加 HTTPS、反向代理、鉴权、
  上传限制和任务清理策略；
- 当前机器未安装 Docker，本 ZIP 已做静态检查，但需要在一台具备
  NVIDIA GPU 和 Docker 的干净电脑上完成最终镜像实机验收。

## 发布前法律检查

请先阅读 `THIRD_PARTY_NOTICE.md`。上游中英文说明的许可证描述存在冲突，
公开发布或商用前必须确认源码和模型权重的准确许可证。
