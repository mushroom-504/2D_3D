此目录用于保存首次启动时自动下载的模型：

models/craftsman-v1-5/config.yaml
models/craftsman-v1-5/model.ckpt

不要将私有 Hugging Face 令牌或无权分发的模型放入公开压缩包。
