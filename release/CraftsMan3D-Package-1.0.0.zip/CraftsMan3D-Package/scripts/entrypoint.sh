#!/usr/bin/env bash
set -euo pipefail

MODEL_NAME="${CRAFTSMAN_MODEL_NAME:-craftsman-v1-5}"
MODEL_DIR="/models/${MODEL_NAME}"

mkdir -p "${MODEL_DIR}" /outputs

python /app/scripts/download_models.py --output "${MODEL_DIR}"
python /app/scripts/preflight.py --model "${MODEL_DIR}"

exec python /app/gradio_app.py \
  --model_path "${MODEL_DIR}" \
  --cached_dir /outputs \
  --host 0.0.0.0 \
  --port 7860
