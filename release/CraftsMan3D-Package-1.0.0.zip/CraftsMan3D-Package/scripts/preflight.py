from __future__ import annotations

import argparse
import platform
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="CraftsMan3D 运行环境检查")
    parser.add_argument("--model", type=Path, required=True)
    args = parser.parse_args()
    errors: list[str] = []

    print(f"[check] Python: {sys.version.split()[0]}")
    print(f"[check] System: {platform.platform()}")

    try:
        import torch

        print(f"[check] PyTorch: {torch.__version__}")
        print(f"[check] CUDA runtime: {torch.version.cuda}")
        if not torch.cuda.is_available():
            errors.append("未检测到 NVIDIA CUDA，发布包不支持纯 CPU 正式推理。")
        else:
            print(f"[check] GPU: {torch.cuda.get_device_name(0)}")
    except Exception as exc:
        errors.append(f"PyTorch 导入失败：{exc}")

    try:
        import torch_cluster  # noqa: F401

        print("[check] torch-cluster: OK")
    except Exception as exc:
        errors.append(f"torch-cluster 导入失败：{exc}")

    try:
        import craftsman  # noqa: F401

        print("[check] craftsman: OK")
    except Exception as exc:
        errors.append(f"CraftsMan 源码导入失败：{exc}")

    for name in ("config.yaml", "model.ckpt"):
        path = args.model / name
        if not path.is_file() or path.stat().st_size == 0:
            errors.append(f"模型文件不存在或为空：{path}")
        else:
            print(f"[check] 模型文件：{path} ({path.stat().st_size:,} bytes)")

    if errors:
        print("\n[check] 环境检查失败：")
        for error in errors:
            print(f"  - {error}")
        return 1

    print("\n[check] 环境检查通过。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
