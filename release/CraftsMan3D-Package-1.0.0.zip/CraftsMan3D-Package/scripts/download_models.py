from __future__ import annotations

import argparse
import os
from pathlib import Path

from huggingface_hub import hf_hub_download


def download_model(repo_id: str, output_dir: Path, token: str | None) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for filename in ("config.yaml", "model.ckpt"):
        target = output_dir / filename
        if target.is_file() and target.stat().st_size > 0:
            print(f"[model] 已存在，跳过：{target}")
            continue
        print(f"[model] 正在下载 {repo_id}/{filename}")
        downloaded = hf_hub_download(
            repo_id=repo_id,
            filename=filename,
            token=token or None,
            local_dir=output_dir,
        )
        print(f"[model] 下载完成：{downloaded}")


def main() -> None:
    parser = argparse.ArgumentParser(description="下载 CraftsMan3D 运行所需模型")
    parser.add_argument(
        "--repo",
        default=os.environ.get(
            "CRAFTSMAN_MODEL_REPO", "craftsman3d/craftsman-v1-5"
        ),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("/models")
        / os.environ.get("CRAFTSMAN_MODEL_NAME", "craftsman-v1-5"),
    )
    args = parser.parse_args()
    download_model(args.repo, args.output, os.environ.get("HF_TOKEN"))


if __name__ == "__main__":
    main()
